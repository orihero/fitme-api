import passportInit from "./passport-init";

const bootstrap = () => {
  passportInit();
};

export default bootstrap;
